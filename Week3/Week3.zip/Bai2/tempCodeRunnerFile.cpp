tream& operator<<(ostream& out, const SoNguyenLon& snl){
    out << snl.soNguyen;
    return out;
}