#include "Bai1.h"

int main(){
    Ngay n1;
    n1.Xuat();
    Ngay n2(02, 10, 2014);
    n2.Xuat();
    Ngay n3(100, 2, 2010);
    n3.Xuat();
    Ngay n4(31);
    n4.Xuat();
}
