#pragma once
#include "Header.h"

class Nguoi{
protected:
    string name;
    string date;
    string address;
public:
    Nguoi();
    void nhap();
    void in();


};