#pragma once
#include "Header.h"

class CongTy;

struct Node{
    CongTy* data;
    Node* next;
};

Node* addTail(Node* ds, CongTy* x);

class CongTy{
private:
    Node* ds;
public:
    CongTy();
    void DanhSachNV();
    virtual void xuat();
    void Add(CongTy* child);
};
