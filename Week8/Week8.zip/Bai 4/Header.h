#pragma once
#include <iostream>
#include <cmath>

using namespace std;