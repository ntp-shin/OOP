#include "HocSinh.h"

HocSinh::HocSinh(){
    hoten = "";
    tuoi = 0;
    dtb = 0;
}

HocSinh::HocSinh(char* hoten1, int tuoi, double dtb){
    this->hoten = hoten1;
    this->tuoi = tuoi;
    this->dtb = dtb;
}

ostream & operator<<(ostream& out, const HocSinh& r){
    out << r.hoten << " " << r.tuoi << " " << r.dtb;
    return out;
}

istream & operator>>(istream& in, HocSinh& r){
    cout << "\nhoten: ";
    cin.ignore();
    getline(in, r.hoten);

    cout << "tuoi: ";
    in >> r.tuoi;

    cout << "dtb: ";
    in >> r.dtb;
    return in;
}

bool HocSinh::operator > (HocSinh & r){
    if(this->dtb > r.dtb)
        return true;
    return false;
}

bool HocSinh::operator < (const HocSinh & r){
    if(this->dtb < r.dtb)
        return true;
    return false;
}

void sapxep(HocSinh a[], int n){
    for(int i = 0; i < n - 2; i++)
        for(int j = 0; j < n - 1 - i; j++)
            if(a[j].dtb > a[j + 1].dtb){
                HocSinh temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
}