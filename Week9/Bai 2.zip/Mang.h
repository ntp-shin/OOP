#pragma once
#include "Header.h"

template<typename Type>
class Mang{
private:
    Type* data;
    int number;
public:
    Mang(){
        data = NULL;
        number = 0;
    }
    Mang(Type* data, int n){
        this->data = data;
        this->number = n;
    }
    ~Mang(){
        delete []data;
    }
    void sort(){
        for(int i = 0; i < number - 1; i++)
            for(int j = 0; j < number - 1 - i; j++)
                if(data[j] > data[j + 1]){
                    Type temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
    }
    int search(const Type& key) const{
        for(int i = 0; i < number; i++)
            if(key == data[i])
                return i;
        return -1;
    }
    void ghifile(const char * tenfile){
        ofstream out;
        out.open(tenfile);
        out << number << endl;
        for(int i = 0; i < number; i++){
            out << data[i] << " ";
        }
        out.close();
    }

    void docfile(const char * tenfile){
        delete []data;

        ifstream in;
        in.open(tenfile);

        in >> number;
        data = new Type[number];
        for(int i = 0; i < number; i++){
            in >> data[i];
        }

        in.close();
    }

    int timmin()const{
        int min = 0;
        for(int i = 1; i < number; i++)
            if(data[i] < data[min])
                min = i;
        return min;
    }

    int timmax()const{
        int max = 0;
        for(int i = 1; i < number; i++)
            if(data[i] > data[max])
                max = i;
        return max;
    }

    void xuat()const{
        for(int i = 0; i < number; i++){
            cout << data[i] << " ";
        }
        cout << endl;
    }

    void nhap(){
        cout << "Nhap number: ";
        cin >> number;
        delete []data;
        data = new Type[number];
        for(int i = 0; i < number; i++){
            cout << "data[" << i << "] = ";
            cin >> data[i];
        }
    }

    bool ktRong()const{
        if(data == NULL)
            return true;
        return false;
    }
};
