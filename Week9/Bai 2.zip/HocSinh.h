#pragma once
#include "Header.h"

class HocSinh{
private:
    string hoten;
    int tuoi;
    double dtb;
public:
    HocSinh();
    HocSinh(char* hoten1, int tuoi, double dtb);

    friend ostream & operator<<(ostream& out, const HocSinh& r);
    friend istream & operator>>(istream& in, HocSinh& r);

    bool operator > (HocSinh & r);
    bool operator < (const HocSinh & r);

    friend void sapxep(HocSinh a[], int n);
};