#pragma once
#include "Mammal.h"

class Horse : public Mammal{
public:
    Horse();
    ~Horse();
    void speak() const;
    void move() const;
};