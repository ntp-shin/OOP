#include "GuineaPig.h"

GuineaPig::GuineaPig():Mammal(){
    cout << "GuineaPig constructor\n";
}

GuineaPig::~GuineaPig(){
    cout << "GuineaPig Destructor\n";
}

void GuineaPig::move() const{
    cout << "GuineaPig move\n";
}

void GuineaPig::speak() const{
    cout << "GuineaPig speak Wheep WHEEP\n";
}