#include "Cat.h"

Cat::Cat():Mammal(){
    cout << "Cat constructor\n";
}

Cat::~Cat(){
    cout << "Cat Destructor\n";
}

void Cat::move() const{
    cout << "Cat move\n";
}

void Cat::speak() const{
    cout << "Cat speak Meow\n";
}