#pragma once
#include "Mammal.h"

class Dog : public Mammal{
public:
    Dog();
    ~Dog();
    void speak() const;
    void move() const;
};