#pragma once
#include "Mammal.h"

class Cat : public Mammal{
public:
    Cat();
    ~Cat();
    void speak() const;
    void move() const;
};