#include "Horse.h"

Horse::Horse():Mammal(){
    cout << "Horse constructor\n";
}

Horse::~Horse(){
    cout << "Horse Destructor\n";
}

void Horse::move() const{
    cout << "Horse move\n";
}

void Horse::speak() const{
    cout << "Horse speak Ney!\n";
}