#include "Header.h"
#include "Mammal.h"
#include "Dog.h"
#include "Cat.h"
#include "Horse.h"
#include "GuineaPig.h"

int main(){
    Mammal* parr[5];
    int choice;
    for(int i = 0; i < 5; i++){
        cout << "(1) Dog    (2) Cat     (3) Horse   (4) Guinea Pig: ";
        cin >> choice;
        switch (choice){
            case (1):
                parr[i] = new Dog;
                break;
            case (2):
                 parr[i] = new Cat;
                break;
            case (3):
                parr[i] = new Horse;
                break;
            case (4):
                parr[i] = new GuineaPig;
                break;
            default:    
                parr[i] = new Mammal;
                break;
        }
    }
    cout << "\n\n ---> Speak: \n";
    for(int i = 0; i < 5; i++){
        parr[i]->speak();
    }

    cout << "\n\n ---> Destructor: \n";
    for(int i = 0; i < 5; i++){
        delete parr[i];
    }
}