#include "Mammal.h"

Mammal::Mammal():itsAge(1){
    cout << "Mammal constructor...\n";
}

Mammal::~Mammal(){
    cout << "Mammal Destructor \n";
}
void Mammal::move() const{
    cout << "Mammal move...\n";
}

void Mammal::speak() const{
    cout << "Mammal speak...\n";
}