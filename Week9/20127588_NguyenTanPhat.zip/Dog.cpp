#include "Dog.h"

Dog::Dog():Mammal(){
    cout << "Dog constructor\n";
}

Dog::~Dog(){
    cout << "Dog Destructor\n";
}

void Dog::move() const{
    cout << "Dog move\n";
}

void Dog::speak() const{
    cout << "Dog speak Woof\n";
}