#pragma once
#include "Header.h"

class Mammal{
public:
    Mammal();
    virtual ~Mammal();

    virtual void move() const;
    virtual void speak() const;
protected:
    int itsAge;
};