#pragma once
#include "Mammal.h"

class GuineaPig : public Mammal{
public:
    GuineaPig();
    ~GuineaPig();
    void speak() const;
    void move() const;
};